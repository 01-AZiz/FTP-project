import numpy as np
import matplotlib.pyplot as plt
from scipy.linalg import eig

def structural_analysis():
    # User input for number of stories
    n_stories = int(input('Enter the number of stories: '))
    
    # Initialize mass and stiffness vectors
    mass_values = np.zeros(n_stories)
    stiffness_values = np.zeros(n_stories)
    
    # Get mass and stiffness values from user
    print("\nEnter mass and stiffness values:")
    for i in range(n_stories):
        mass_values[i] = float(input(f'Enter mass for story {i+1} (kg): '))
        stiffness_values[i] = float(input(f'Enter stiffness for story {i+1} (N/m): '))
    
    # Display the input values for verification
    print('\nMass values (kg):')
    print(mass_values)
    print('Stiffness values (N/m):')
    print(stiffness_values)
    
    # Initialize matrices
    K = np.zeros((n_stories, n_stories))
    M = np.zeros((n_stories, n_stories))
    
    # Build stiffness matrix
    for i in range(n_stories):
        if i == 0:
            # First story
            K[i,i] = stiffness_values[i] + stiffness_values[i+1] if n_stories > 1 else stiffness_values[i]
            if n_stories > 1:
                K[i,i+1] = -stiffness_values[i+1]
        elif i == n_stories - 1:
            # Last story
            K[i,i] = stiffness_values[i]
            K[i,i-1] = -stiffness_values[i]
        else:
            # Intermediate stories
            K[i,i] = stiffness_values[i] + stiffness_values[i+1]
            K[i,i-1] = -stiffness_values[i]
            K[i,i+1] = -stiffness_values[i+1]
    
    # Make stiffness matrix symmetric
    for i in range(n_stories):
        for j in range(i+1, n_stories):
            if K[i,j] != 0 and K[j,i] == 0:
                K[j,i] = K[i,j]
    
    # Build mass matrix (diagonal)
    for i in range(n_stories):
        M[i,i] = mass_values[i]
    
    # Solve eigenvalue problem
    # Using scipy.linalg.eig 
    eigenvalues, eigenvectors = eig(K, M)
    
    # Extract natural frequencies and periods
    omega = np.sqrt(np.real(eigenvalues))  # Natural frequencies (rad/s)
    f_n = omega / (2 * np.pi)             # Natural frequencies (Hz)
    T = 2 * np.pi / omega                 # Natural periods (seconds)
    
    # Sort by period (ascending order - fundamental mode first)
    sort_idx = np.argsort(T)
    T = T[sort_idx]
    omega = omega[sort_idx]
    f_n = f_n[sort_idx]
    eigenvectors = eigenvectors[:, sort_idx]
    
    print('\nNatural Frequencies (Hz):')
    print(f_n)
    print('\nNatural Periods (s):')
    print(T)
    
    # Mode shapes - normalize relative to maximum absolute value
    phi = np.zeros((n_stories, n_stories))
    for i in range(n_stories):
        max_idx = np.argmax(np.abs(eigenvectors[:, i]))  # Find index of max absolute value
        phi[:, i] = np.real(eigenvectors[:, i] / eigenvectors[max_idx, i])  # Normalize
    
    print('\nMode Shapes (normalized):')
    print(phi)
    
    # Rayleigh Damping Calculation
    zeta = float(input('\nEnter damping ratio (e.g., 0.04 for 4%): '))
    
    # Use first two modes for Rayleigh damping
    if n_stories >= 2:
        A = np.array([
            [1/(2*omega[0]), omega[0]/2],
            [1/(2*omega[1]), omega[1]/2]
        ])
        b = np.array([zeta, zeta])
        
        X = np.linalg.solve(A, b)
        a0 = X[0]
        b0 = X[1]
        
        # Damping matrix
        Cs = a0 * M + b0 * K
        
        print(f'\nRayleigh damping coefficients:')
        print(f'a0 = {a0:.6f}')
        print(f'b0 = {b0:.6e}')
        print("Cs=",Cs)
    else:
        print('Warning: Need at least 2 stories for Rayleigh damping calculation.')
        Cs = np.zeros((n_stories, n_stories))
    
    # Optional: Plot mode shapes
    plot_mode_shapes = int(input('\nPlot mode shapes? (1 for yes, 0 for no): '))
    if plot_mode_shapes:
        plt.figure(figsize=(15, 5))
        n_plots = min(5, n_stories)
        for i in range(n_plots):
            plt.subplot(1, n_plots, i+1)
            plt.plot(phi[:, i], range(1, n_stories+1), 'o-', linewidth=2, markersize=6)
            plt.title(f'Mode Shape {i+1}')
            plt.xlabel('Amplitude')
            plt.ylabel('Story Level')
            plt.grid(True)
            plt.yticks(range(1, n_stories+1))
        plt.tight_layout()
        plt.show()
    
    # Display matrices
    print('\nMass Matrix (kg):')
    print(M)
    print('\nStiffness Matrix (N/m):')
    print(K)
    print('\nDamping Matrix (Ns/m):')
    print(Cs)
    
    return M, K, Cs, T, phi, omega
M, K, Cs, T, phi, omega = structural_analysis()